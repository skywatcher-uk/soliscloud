# SolisCloud

A small library to work with the Solis Cloud API for some simple
data gathering and setting.